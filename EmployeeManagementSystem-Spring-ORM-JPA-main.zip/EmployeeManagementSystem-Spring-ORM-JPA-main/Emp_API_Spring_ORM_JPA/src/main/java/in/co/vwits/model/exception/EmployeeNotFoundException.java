package in.co.vwits.model.exception;

public class EmployeeNotFoundException extends Exception {

}
